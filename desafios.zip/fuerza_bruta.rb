=begin
Se busca crear un programa fuerza_bruta.rb que revise cuantos intentos requiere hackear un
password por fuerza bruta.
=end

Uso:
ruby fuerza_bruta.rb pass
282404 intentos
ruby fuerza_bruta.rb passwo
190906392 intentos